#!/usr/bin/env python3
"""Add the exact watermark to the bottom-right of an image.

Usage: python add_watermark.py <input> <output>
"""
import sys
from PIL import Image, ImageDraw, ImageFont

TEXT = "© fusilini-illustrations-by-aish"

def load_font(size):
    for path in (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    ):
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            continue
    return ImageFont.load_default()

def main(src, dst):
    img = Image.open(src).convert("RGB")
    w, h = img.size
    draw = ImageDraw.Draw(img)
    font = load_font(max(12, round(h * 0.022)))
    bbox = draw.textbbox((0, 0), TEXT, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    margin = round(min(w, h) * 0.03)
    draw.text((w - tw - margin - bbox[0], h - th - margin - bbox[1]), TEXT, fill=(0, 0, 0), font=font)
    img.save(dst)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
