# QA Checklist

After generating, check each:

- [ ] Reads in about one second; the single idea is clear
- [ ] The fusilini is performing the core action (not decorating)
- [ ] The fusilini looks like a tight corkscrew pasta, not a worm, spring, or penne
- [ ] Pure white background; black line art; exactly one warm-orange accent
- [ ] At least ~50% whitespace; no crowding
- [ ] 5-8 labels max, all legible, no garbled text
- [ ] No top-left title, no PPT/infographic look
- [ ] Tone is deadpan, not cute or childish
- [ ] Bottom-right corner is empty for the watermark
- [ ] Metaphor is fresh, not repeated from earlier in the session

## Iteration moves
- Too busy → remove an object, cut labels, shrink the fusilini's props.
- Fusilini decorative → rewrite the action so it carries, turns, weighs, or fixes the main object.
- Garbled text → shorten labels or regenerate; fix only if a local edit is trivial.
- Second color appeared → regenerate with the accent restated; or recolor locally.
- Looks cute → restate "blank, serious, deadpan" and remove blush/mouth/sparkles.
