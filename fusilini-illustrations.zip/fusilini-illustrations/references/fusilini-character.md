# The Fusilini

## Form
- One piece of fusilli: a tight corkscrew spiral, 3-4 visible turns, drawn as a single continuous wobbly black line with slight thickness.
- Two small dot eyes sit on the top curl; no mouth, or one flat short line at most.
- Two thin stick legs from the bottom curl, small round feet or just line ends.
- Optional: thin stick arms only when the action needs hands. Keep them minimal.
- Roughly 1/6 to 1/4 of the canvas height. Big enough to read, small enough to leave whitespace.
- Warm-orange may appear on the fusilini only as a light fill on the spiral ridges or as a single accent (e.g., a sauce stain), never both unless the orange is the one accent for the whole image.

## Personality
Deadpan, earnest, unbothered. It treats absurd tasks as serious work. Never smiling, never panicking, never winking at the viewer.

## Action vocabulary
Carrying, untwisting, stacking, threading through something, sorting, weighing, measuring with a ruler, boiling a tiny pot of "process", stirring, draining through a sieve (filtering), hanging from a hook, balancing on a fork, pushing a boulder-sized meatball, tightening or loosening its own spiral to show tension and relaxation.

Spiral-specific tricks: a stretched-out spiral can show growth or strain; a tightly wound spiral can show pressure or focus; a spiral threaded onto a fork prong can show being stuck or selected.

## Don'ts
- Not a worm, a spring, a DNA helix, or penne. Keep the spiral tight and short.
- No cute face, blush, sparkles, or mascot energy.
- No more than one fusilini unless the idea needs a contrast (then at most two, clearly different states).
- Never standing next to the action as a bystander.
