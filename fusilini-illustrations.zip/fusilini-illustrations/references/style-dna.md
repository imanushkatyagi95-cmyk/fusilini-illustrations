# Style DNA

- **Line**: black, hand-drawn, slightly wobbly, confident, medium-thin weight. Marker or fineliner feel. No perfect geometry, no vector sheen.
- **Color**: pure white background, black line art, exactly one warm-orange accent (roughly #F28C28). Use it on one or two elements that carry the idea. No gradients, no second accent, no gray fills.
- **Whitespace**: generous. Roughly 50% or more of the canvas stays empty. One main object plus the fusilini, a few labels.
- **Labels**: short handwritten English, 1-4 words each, 5-8 maximum. Arrows are loose and hand-drawn.
- **Format**: 16:9 horizontal.

## Hard nos
- PPT or infographic look, boxes with bullet points, icons grids
- Top-left type-title or headline
- Commercial illustration polish, stock-art vibes
- Childish cuteness, kawaii faces
- Complex architecture or flow diagrams
- Shadows, textures, paper backgrounds
- Rendered watermark text (it is added locally afterward)
