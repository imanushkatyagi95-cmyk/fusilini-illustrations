# Single-Image Prompt Template

Fill in the brackets, then send as one prompt to the image tool.

```
A 16:9 horizontal hand-drawn concept illustration on a pure white background.
Black wobbly marker-style line art with exactly one warm-orange accent color (#F28C28) and no other colors.
Subject: a deadpan fusilini, a single tight corkscrew pasta spiral with two dot eyes on the top curl and two thin stick legs, blank serious expression.
Action: [FUSILINI'S ACTION] using [MAIN OBJECT / METAPHOR].
The warm-orange accent is used only on [ORANGE ELEMENT].
Handwritten English labels, short and neat: [LABEL 1], [LABEL 2], [LABEL 3] (max 8).
Composition: [WHERE THE FUSILINI SITS, WHERE THE OBJECT SITS, EYE PATH].
Lots of whitespace. Keep the bottom-right corner empty and quiet.
Style: clean, deadpan, slightly absurd, one idea per image.
Avoid: PPT or infographic look, commercial illustration polish, childish cuteness, complex diagrams, title text in the top-left, shadows, gradients, textures, any watermark or signature text.
```
