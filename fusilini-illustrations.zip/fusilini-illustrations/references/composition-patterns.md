# Composition Patterns

Pick the structure by the kind of idea, then invent a fresh low-tech metaphor. Use everyday objects: kitchen tools, strainers, scales, pots, shelves, ropes, ladders, doors, pipes, buckets, rulers.

| Idea type | Structure | Pasta-flavored example |
|---|---|---|
| Judgment | Fusilini weighs/inspects one object | Fusilini squints through a magnifier at a sauce jar labeled "trust me" |
| Process (input → output) | Left-to-right path with one transformation point | Fusilini feeds raw spaghetti-sized ideas into a pasta press, tidy spirals come out |
| Contrast (before/after) | Two zones, same fusilini in two states | Tightly wound and tense vs. relaxed and stretched out |
| State / feeling | Fusilini in a small situation that says it | Fusilini sits in a colander while everything drains away |
| Concept metaphor | One strong object does the explaining | Fusilini tightens a single bolt on a giant fork |

## Inventing a fresh metaphor
1. Name the single idea in one sentence.
2. List 3 physical objects that behave like the idea.
3. Choose the least obvious one that still reads in one second.
4. Give the fusilini a task with that object that costs it visible effort.
5. Do not reuse a metaphor from earlier images in the session.

## Eye path
Start at the fusilini, travel to the main object, end at the orange accent. Keep the lower-right corner empty for the watermark.
